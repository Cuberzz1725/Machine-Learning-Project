from flask import Flask, Response, render_template,jsonify
import cv2
import numpy as np
from ultralytics import YOLO
import threading
import requests
import time

app = Flask(__name__, template_folder="templates")  # Set template folder

# Load YOLO model
model = YOLO("yolov8n.pt")

# OpenCV video capture
#cap = cv2.VideoCapture(0)  # Use default webcam
# Separate heavy vehicle labels
HEAVY_VEHICLES = ["bus", "truck"]
LIGHT_VEHICLES = ["car", "motorcycle"]
VEHICLE_LABELS = HEAVY_VEHICLES + LIGHT_VEHICLES

CAM_URL = "http://192.168.159.129/cam-mid.jpg"
ESP_IP = "http://192.168.159.195"



# Detection flags
left_detected = False
right_detected = False
lock = threading.Lock()

def send_signal(signal):
    url = f"{ESP_IP}/SIGNAL?data={signal}"
    try:
        response = requests.get(url, timeout=5)  # 5 seconds timeout
        if response.status_code == 200:
            print(f"✅ Signal {signal} Sent Successfully!")
            print("Response:", response.text)
        else:
            print(f"⚠️ Failed to Send Signal {signal}. HTTP Code:", response.status_code)
            print("Response:", response.text)
    except requests.exceptions.RequestException as e:
        print(f"❌ Error Sending Signal {signal}: {e}")

def process_frame(frame):
    """Runs YOLO inference, detects vehicles/animals, prioritizes heavy vehicles, and sends alerts."""
    global left_detected, right_detected

    height, width, _ = frame.shape
    center_x = width // 2

    detected_left = detected_right = False
    heavy_left = heavy_right = False
    animal_detected = False

    results = model.predict(frame, conf=0.5, verbose=False)

    for r in results:
        for box in r.boxes:
            label = model.names[int(box.cls[0].item())]

            
            if label in VEHICLE_LABELS:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                centroid_x = (x1 + x2) // 2

                if centroid_x < center_x:
                    detected_left = True
                    if label in HEAVY_VEHICLES:
                        heavy_left = True
                else:
                    detected_right = True
                    if label in HEAVY_VEHICLES:
                        heavy_right = True

    with lock:
        if detected_left and detected_right:
            if heavy_left and not heavy_right:
                print("🚛 Heavy vehicle LEFT! Prioritize RIGHT alert.")
                send_signal(1)
                left_detected = True
                right_detected = False
            elif heavy_right and not heavy_left:
                print("🚛 Heavy vehicle RIGHT! Prioritize LEFT alert.")
                send_signal(2)
                right_detected = True
                left_detected = False
            else:
                # Default to centroid-based logic if both sides are same type
                if not left_detected:
                    print("🚗 Vehicles both sides. Defaulting to LEFT priority.")
                    send_signal(1)
                    left_detected = True
                    right_detected = False

        elif detected_left and not left_detected:
            print("🚗 Vehicle LEFT detected. Alert RIGHT.")
            send_signal(1)
            left_detected = True
            right_detected = False

        elif detected_right and not right_detected:
            print("🚗 Vehicle RIGHT detected. Alert LEFT.")
            send_signal(2)
            right_detected = True
            left_detected = False

        elif not detected_left and not detected_right:
            if left_detected or right_detected:
                print("✅ No vehicle. Clearing alerts.")
                send_signal(0)
            left_detected = right_detected = False

    return frame


def generate_frames():
    """Fetches frames from ESP32-CAM, processes them, and streams via Flask."""
    while True:
        try:
            response = requests.get(CAM_URL, timeout=2)
            if response.status_code == 200:
                img_array = np.frombuffer(response.content, np.uint8)
                frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                
                # Process frame with YOLO
                frame = process_frame(frame)
                
                _, buffer = cv2.imencode('.jpg', frame)
                frame_bytes = buffer.tobytes()

                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        except Exception as e:
            print(f"Error fetching from camera: {e}")
            continue

@app.route('/')
def index():
    """Serve the HTML file as the homepage."""
    return render_template("index.html")

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)